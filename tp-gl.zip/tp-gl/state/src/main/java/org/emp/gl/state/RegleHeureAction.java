/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.state;

import org.emp.gl.actions.Actions;
import org.emp.gl.model.MyWatch;

/**
 *
 * @author Hichem
 */
public class RegleHeureAction implements Actions{
    
    MyWatch mywatch;

    RegleHeureAction(MyWatch mywatch){
        this.mywatch = mywatch;
    }

    @Override
    public void doConfig() {
        this.mywatch.ChangeAction(new NormaleAction(this.mywatch));
    }

    @Override
    public void doMode() {
        this.mywatch.ChangeAction(new RegleSecondeAction(this.mywatch));
    }

    @Override
    public void doIncrement() {
        this.mywatch.IncHeures();
    }
    
}
